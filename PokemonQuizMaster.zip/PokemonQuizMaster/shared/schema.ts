import { z } from "zod";

// Pokemon type definitions
export const pokemonTypes = [
  "Normal", "Fire", "Water", "Electric", "Grass", "Ice",
  "Fighting", "Poison", "Ground", "Flying", "Psychic", "Bug",
  "Rock", "Ghost", "Dragon", "Dark", "Steel", "Fairy"
] as const;

export type PokemonType = typeof pokemonTypes[number];

// Region definitions
export const regions = [
  "Kanto", "Johto", "Hoenn", "Sinnoh", "Unova",
  "Kalos", "Alola", "Galar", "Paldea", "General"
] as const;

export type Region = typeof regions[number];

// Difficulty levels
export const difficulties = ["Fácil", "Media", "Difícil", "Experto"] as const;
export type Difficulty = typeof difficulties[number];

// Pokemon schema
export const pokemonSchema = z.object({
  id: z.number(),
  name: z.string(),
  number: z.number(),
  types: z.array(z.enum(pokemonTypes)),
  region: z.enum(regions),
  spriteUrl: z.string(),
});

export type Pokemon = z.infer<typeof pokemonSchema>;

// Game session schema
export const gameSessionSchema = z.object({
  region: z.enum(regions),
  difficulty: z.enum(difficulties),
  score: z.number(),
  currentStreak: z.number(),
  questionsAnswered: z.number(),
  correctAnswers: z.number(),
});

export type GameSession = z.infer<typeof gameSessionSchema>;

// Answer validation schema
export const answerSchema = z.object({
  pokemonId: z.number(),
  difficulty: z.enum(difficulties),
  answer: z.object({
    name: z.string().optional(),
    type: z.array(z.enum(pokemonTypes)).optional(),
    number: z.number().optional(),
  }),
});

export type Answer = z.infer<typeof answerSchema>;

// Answer validation response
export const answerResponseSchema = z.object({
  correct: z.boolean(),
  correctAnswer: z.object({
    name: z.string(),
    type: z.array(z.enum(pokemonTypes)),
    number: z.number(),
  }),
  message: z.string().optional(),
});

export type AnswerResponse = z.infer<typeof answerResponseSchema>;
