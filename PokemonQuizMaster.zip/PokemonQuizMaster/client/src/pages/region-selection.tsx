import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home, Star } from "lucide-react";
import { type Region } from "@shared/schema";

// Import region icons
import kantoIcon from "@assets/generated_images/Kanto_region_icon_68b79b1e.png";
import johtoIcon from "@assets/generated_images/Johto_region_icon_66fc53af.png";
import hoennIcon from "@assets/generated_images/Hoenn_region_icon_5118e70a.png";
import sinnohIcon from "@assets/generated_images/Sinnoh_region_icon_e7d3a0ee.png";
import unovaIcon from "@assets/generated_images/Unova_region_icon_9bba70fb.png";
import kalosIcon from "@assets/generated_images/Kalos_region_icon_ff2e0ad8.png";
import alolaIcon from "@assets/generated_images/Alola_region_icon_60966841.png";
import galarIcon from "@assets/generated_images/Galar_region_icon_a7586ad5.png";
import paldeaIcon from "@assets/generated_images/Paldea_region_icon_72c95083.png";

interface RegionData {
  name: Region;
  generation: string;
  icon: string;
  color: string;
}

const regions: RegionData[] = [
  { name: "Kanto", generation: "Gen I", icon: kantoIcon, color: "from-purple-500 to-purple-700" },
  { name: "Johto", generation: "Gen II", icon: johtoIcon, color: "from-yellow-500 to-orange-500" },
  { name: "Hoenn", generation: "Gen III", icon: hoennIcon, color: "from-blue-500 to-cyan-500" },
  { name: "Sinnoh", generation: "Gen IV", icon: sinnohIcon, color: "from-indigo-500 to-purple-500" },
  { name: "Unova", generation: "Gen V", icon: unovaIcon, color: "from-gray-700 to-gray-900" },
  { name: "Kalos", generation: "Gen VI", icon: kalosIcon, color: "from-blue-400 to-pink-400" },
  { name: "Alola", generation: "Gen VII", icon: alolaIcon, color: "from-orange-400 to-pink-500" },
  { name: "Galar", generation: "Gen VIII", icon: galarIcon, color: "from-cyan-500 to-purple-600" },
  { name: "Paldea", generation: "Gen IX", icon: paldeaIcon, color: "from-red-500 to-violet-600" },
];

export default function RegionSelection() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/80 backdrop-blur-sm border-b border-card-border">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" size="icon" data-testid="button-home">
              <Home className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="font-game text-sm sm:text-base md:text-lg text-foreground">
            Quiz Master
          </h1>
          <div className="w-10" />
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:py-12 animate-slide-up">
        {/* Title Section */}
        <div className="text-center mb-8 sm:mb-12">
          <div className="inline-flex items-center justify-center gap-2 mb-4">
            <div className="w-8 h-8 bg-pokemon-red rounded-full" />
            <h2 className="font-game text-2xl sm:text-3xl md:text-4xl text-foreground uppercase">
              Elige tu Región
            </h2>
            <div className="w-8 h-8 bg-pokemon-yellow rounded-full" />
          </div>
          <p className="text-muted-foreground text-sm sm:text-base">
            Selecciona una región de Pokémon para comenzar tu desafío
          </p>
        </div>

        {/* Regions Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-8">
          {regions.map((region) => (
            <Link key={region.name} href={`/dificultad/${region.name.toLowerCase()}`}>
              <Card 
                className="group cursor-pointer overflow-hidden hover-elevate active-elevate-2 transition-all duration-300 hover:-translate-y-2 border-2"
                data-testid={`card-region-${region.name.toLowerCase()}`}
              >
                <div className="relative aspect-[4/3]">
                  {/* Gradient Background */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${region.color} opacity-80 group-hover:opacity-90 transition-opacity`} />
                  
                  {/* Icon */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <img 
                      src={region.icon} 
                      alt={region.name}
                      className="w-32 h-32 sm:w-40 sm:h-40 object-contain opacity-40 group-hover:opacity-60 transition-opacity group-hover:scale-110 duration-300"
                    />
                  </div>

                  {/* Text Overlay */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                    <h3 className="font-game text-xl sm:text-2xl mb-2 drop-shadow-lg">
                      {region.name}
                    </h3>
                    <span className="text-sm font-semibold bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full">
                      {region.generation}
                    </span>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>

        {/* General Mode Card - Special */}
        <div className="max-w-2xl mx-auto">
          <Link href="/dificultad/general">
            <Card 
              className="group cursor-pointer overflow-hidden hover-elevate active-elevate-2 transition-all duration-300 hover:-translate-y-2 border-4 border-pokemon-yellow"
              data-testid="card-region-general"
            >
              <div className="relative aspect-[16/6]">
                {/* Rainbow Gradient Background */}
                <div className="absolute inset-0 bg-gradient-to-r from-pokemon-red via-pokemon-yellow to-pokemon-blue opacity-90 group-hover:opacity-100 transition-opacity" />
                
                {/* Animated overlay */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse" />

                {/* Text Overlay */}
                <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                  <div className="flex items-center gap-2 mb-2">
                    <Star className="w-6 h-6 fill-pokemon-yellow text-pokemon-yellow animate-pulse-scale" />
                    <h3 className="font-game text-2xl sm:text-3xl drop-shadow-lg">
                      Modo General
                    </h3>
                    <Star className="w-6 h-6 fill-pokemon-yellow text-pokemon-yellow animate-pulse-scale" />
                  </div>
                  <p className="text-sm sm:text-base font-semibold">
                    Todas las Regiones • Máximo Desafío
                  </p>
                </div>
              </div>
            </Card>
          </Link>
        </div>

        {/* Breadcrumb */}
        <div className="text-center mt-8 text-sm text-muted-foreground">
          Inicio → <span className="font-semibold">Regiones</span>
        </div>
      </main>
    </div>
  );
}
