import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";
import heroImage from "@assets/generated_images/Pokemon_hero_banner_image_fe3f6bc5.png";

export default function Home() {
  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background gradient */}
      <div 
        className="absolute inset-0 bg-gradient-to-br from-pokemon-red via-[#FB6C6C] to-pokemon-yellow"
        style={{
          backgroundImage: `linear-gradient(135deg, #EE1515 0%, #FB6C6C 50%, #FFCB05 100%)`
        }}
      />
      
      {/* Hero Image with dark wash */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${heroImage})`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/30 to-black/50" />
      </div>

      {/* Floating Pokeballs decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-16 h-16 bg-white/10 rounded-full animate-float" style={{ animationDelay: '0s' }} />
        <div className="absolute top-40 right-20 w-12 h-12 bg-white/10 rounded-full animate-float" style={{ animationDelay: '1s' }} />
        <div className="absolute bottom-32 left-1/4 w-20 h-20 bg-white/10 rounded-full animate-float" style={{ animationDelay: '2s' }} />
        <div className="absolute bottom-20 right-1/3 w-14 h-14 bg-white/10 rounded-full animate-float" style={{ animationDelay: '1.5s' }} />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto animate-slide-up">
        {/* Title */}
        <h1 className="font-game text-white text-3xl sm:text-4xl md:text-5xl lg:text-6xl mb-4 drop-shadow-lg uppercase leading-tight">
          Pokémon
          <br />
          <span className="text-pokemon-yellow">Quiz Master</span>
        </h1>

        {/* Tagline */}
        <p className="text-white text-lg sm:text-xl md:text-2xl font-semibold mb-8 drop-shadow-md">
          ¿Cuánto sabes sobre Pokémon?
        </p>

        {/* CTA Button */}
        <Link href="/regiones">
          <Button
            size="lg"
            data-testid="button-start-adventure"
            className="bg-white hover:bg-white/90 text-pokemon-red font-bold text-base sm:text-lg px-8 sm:px-12 py-6 sm:py-8 rounded-full shadow-2xl hover:scale-105 transition-all duration-300 uppercase tracking-wide group"
          >
            <Sparkles className="mr-2 h-5 w-5 sm:h-6 sm:w-6 group-hover:animate-pulse-scale" />
            Comenzar Aventura
          </Button>
        </Link>

        {/* Subtitle */}
        <p className="text-white/90 text-sm sm:text-base mt-6 drop-shadow-md">
          Pon a prueba tus conocimientos en todas las regiones
        </p>
      </div>
    </div>
  );
}
