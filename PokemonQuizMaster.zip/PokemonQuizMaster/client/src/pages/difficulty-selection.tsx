import { Link, useParams, useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home, ChevronLeft, Star } from "lucide-react";
import { type Difficulty } from "@shared/schema";

interface DifficultyOption {
  name: Difficulty;
  description: string;
  challenge: string;
  color: string;
  bgColor: string;
  stars: number;
}

const difficulties: DifficultyOption[] = [
  {
    name: "Fácil",
    description: "Adivina el NOMBRE",
    challenge: "Se muestra la imagen del Pokémon",
    color: "text-easy-green",
    bgColor: "bg-easy-green",
    stars: 1,
  },
  {
    name: "Media",
    description: "Adivina el TIPO",
    challenge: "Se muestra imagen y nombre del Pokémon",
    color: "text-medium-yellow",
    bgColor: "bg-medium-yellow",
    stars: 2,
  },
  {
    name: "Difícil",
    description: "Adivina el NÚMERO de Pokédex",
    challenge: "Se muestra imagen y nombre del Pokémon",
    color: "text-hard-orange",
    bgColor: "bg-hard-orange",
    stars: 3,
  },
];

const expertDifficulty: DifficultyOption = {
  name: "Experto",
  description: "¡TODO! Nombre + Tipo + Número",
  challenge: "Solo se muestra la imagen del Pokémon",
  color: "text-expert-red",
  bgColor: "bg-expert-red",
  stars: 4,
};

export default function DifficultySelection() {
  const params = useParams();
  const [, navigate] = useLocation();
  const region = params.region as string;
  const regionName = region.charAt(0).toUpperCase() + region.slice(1);
  const isGeneral = region === "general";

  // Show expert mode only for General
  const availableDifficulties = isGeneral 
    ? [...difficulties, expertDifficulty]
    : difficulties;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/80 backdrop-blur-sm border-b border-card-border">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" size="icon" data-testid="button-home">
              <Home className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="font-game text-sm sm:text-base md:text-lg text-foreground">
            Quiz Master
          </h1>
          <Link href="/regiones">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ChevronLeft className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8 sm:py-12 animate-slide-up">
        {/* Title Section */}
        <div className="text-center mb-8 sm:mb-12">
          <div className="inline-flex items-center justify-center gap-2 mb-2">
            <div className="w-6 h-6 bg-pokemon-blue rounded-full" />
            <h2 className="font-game text-base sm:text-lg md:text-xl text-foreground uppercase">
              Región: {regionName}
            </h2>
            <div className="w-6 h-6 bg-pokemon-blue rounded-full" />
          </div>
          <h3 className="font-game text-2xl sm:text-3xl md:text-4xl text-foreground uppercase mb-3">
            Elige Dificultad
          </h3>
          <p className="text-muted-foreground text-sm sm:text-base">
            Selecciona el nivel de desafío que prefieras
          </p>
        </div>

        {/* Difficulty Cards */}
        <div className="space-y-4 sm:space-y-6">
          {availableDifficulties.map((difficulty) => (
            <Link 
              key={difficulty.name} 
              href={`/juego/${region}/${difficulty.name.toLowerCase()}`}
            >
              <Card
                className="group cursor-pointer overflow-hidden hover-elevate active-elevate-2 transition-all duration-300 hover:-translate-y-1 border-2"
                data-testid={`card-difficulty-${difficulty.name.toLowerCase()}`}
              >
                <div className="flex flex-col sm:flex-row items-stretch">
                  {/* Color Indicator */}
                  <div className={`${difficulty.bgColor} w-full sm:w-24 h-3 sm:h-auto flex items-center justify-center`}>
                    <div className="hidden sm:flex flex-col items-center gap-1 py-4">
                      {Array.from({ length: difficulty.stars }).map((_, i) => (
                        <Star 
                          key={i} 
                          className="w-5 h-5 fill-white text-white" 
                        />
                      ))}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className={`font-game text-xl sm:text-2xl ${difficulty.color} mb-2`}>
                          {difficulty.name}
                        </h4>
                        <p className="text-foreground font-semibold text-base sm:text-lg">
                          {difficulty.description}
                        </p>
                      </div>
                      {/* Stars for mobile */}
                      <div className="flex sm:hidden gap-1">
                        {Array.from({ length: difficulty.stars }).map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-4 h-4 ${difficulty.color} fill-current`}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-muted-foreground text-sm sm:text-base">
                      {difficulty.challenge}
                    </p>
                  </div>

                  {/* Arrow indicator */}
                  <div className="hidden sm:flex items-center pr-6">
                    <div className="text-muted-foreground group-hover:text-foreground group-hover:translate-x-1 transition-all">
                      →
                    </div>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>

        {/* Info box for Expert mode */}
        {isGeneral && (
          <div className="mt-8 p-4 bg-expert-red/10 border-2 border-expert-red rounded-lg">
            <p className="text-sm text-center text-foreground">
              <span className="font-bold text-expert-red">Modo Experto</span> solo disponible en Modo General
            </p>
          </div>
        )}

        {/* Breadcrumb */}
        <div className="text-center mt-8 text-sm text-muted-foreground">
          Inicio → Regiones → <span className="font-semibold">{regionName}</span> → Dificultad
        </div>
      </main>
    </div>
  );
}
