import { useEffect, useState } from "react";
import { useLocation, Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trophy, Star, Home, RotateCcw, Map } from "lucide-react";

export default function ResultsScreen() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1]);
  
  const score = parseInt(searchParams.get('score') || '0');
  const correct = parseInt(searchParams.get('correct') || '0');
  const total = parseInt(searchParams.get('total') || '0');
  const region = searchParams.get('region') || '';
  const difficulty = searchParams.get('difficulty') || '';
  
  const regionName = region.charAt(0).toUpperCase() + region.slice(1);
  const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;

  // Confetti animation
  const [showConfetti, setShowConfetti] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setShowConfetti(false), 3000);
    return () => clearTimeout(timer);
  }, []);

  // Performance rating
  const getRating = () => {
    if (accuracy >= 90) return { text: "¡Maestro Pokémon!", stars: 5, color: "text-pokemon-yellow" };
    if (accuracy >= 75) return { text: "¡Excelente!", stars: 4, color: "text-easy-green" };
    if (accuracy >= 60) return { text: "¡Bien Hecho!", stars: 3, color: "text-pokemon-blue" };
    if (accuracy >= 40) return { text: "Sigue Practicando", stars: 2, color: "text-medium-yellow" };
    return { text: "Inténtalo de Nuevo", stars: 1, color: "text-muted-foreground" };
  };

  const rating = getRating();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background relative overflow-hidden">
      {/* Floating Pokeballs Background */}
      {showConfetti && (
        <div className="absolute inset-0 pointer-events-none">
          {Array.from({ length: 20 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-8 h-8 bg-pokemon-red/20 rounded-full animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${3 + Math.random() * 2}s`,
              }}
            />
          ))}
        </div>
      )}

      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/80 backdrop-blur-sm border-b border-card-border">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" size="icon" data-testid="button-home">
              <Home className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="font-game text-sm sm:text-base md:text-lg text-foreground">
            Resultados
          </h1>
          <div className="w-10" />
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-4 py-8 sm:py-12 animate-slide-up">
        {/* Main Results Card */}
        <Card className="p-8 sm:p-12 text-center mb-8 border-2">
          {/* Trophy Icon */}
          <div className="flex justify-center mb-6">
            <div className="relative">
              <Trophy className={`w-20 h-20 sm:w-24 sm:h-24 ${rating.color} animate-pulse-scale`} />
              {accuracy >= 90 && (
                <div className="absolute -top-2 -right-2">
                  <Star className="w-8 h-8 fill-pokemon-yellow text-pokemon-yellow animate-pulse" />
                </div>
              )}
            </div>
          </div>

          {/* Rating */}
          <h2 className={`font-game text-2xl sm:text-3xl mb-4 ${rating.color}`}>
            {rating.text}
          </h2>

          {/* Stars */}
          <div className="flex justify-center gap-2 mb-6">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`w-6 h-6 sm:w-8 sm:h-8 ${
                  i < rating.stars
                    ? "fill-pokemon-yellow text-pokemon-yellow"
                    : "text-muted-foreground"
                }`}
              />
            ))}
          </div>

          {/* Score */}
          <div className="space-y-4 mb-6">
            <div>
              <p className="text-muted-foreground text-sm mb-1">Puntuación Total</p>
              <p className="font-game text-4xl sm:text-5xl text-pokemon-blue" data-testid="text-final-score">
                {score}
              </p>
            </div>

            {/* Accuracy Circle */}
            <div className="flex justify-center">
              <div className="relative w-32 h-32 sm:w-40 sm:h-40">
                <svg className="transform -rotate-90 w-full h-full">
                  <circle
                    cx="50%"
                    cy="50%"
                    r="45%"
                    stroke="currentColor"
                    strokeWidth="8"
                    fill="none"
                    className="text-muted"
                  />
                  <circle
                    cx="50%"
                    cy="50%"
                    r="45%"
                    stroke="currentColor"
                    strokeWidth="8"
                    fill="none"
                    strokeDasharray={`${2 * Math.PI * 45}`}
                    strokeDashoffset={`${2 * Math.PI * 45 * (1 - accuracy / 100)}`}
                    className="text-easy-green transition-all duration-1000"
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <p className="font-game text-2xl sm:text-3xl text-foreground" data-testid="text-accuracy">
                    {accuracy}%
                  </p>
                  <p className="text-xs text-muted-foreground">Precisión</p>
                </div>
              </div>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
            <div>
              <Badge variant="outline" className="w-full justify-center py-2">
                <div className="text-center">
                  <p className="font-bold text-lg" data-testid="text-correct-answers">{correct}</p>
                  <p className="text-xs">Correctas</p>
                </div>
              </Badge>
            </div>
            <div>
              <Badge variant="outline" className="w-full justify-center py-2">
                <div className="text-center">
                  <p className="font-bold text-lg" data-testid="text-incorrect-answers">{total - correct}</p>
                  <p className="text-xs">Incorrectas</p>
                </div>
              </Badge>
            </div>
            <div>
              <Badge variant="outline" className="w-full justify-center py-2">
                <div className="text-center">
                  <p className="font-bold text-lg" data-testid="text-total-questions">{total}</p>
                  <p className="text-xs">Total</p>
                </div>
              </Badge>
            </div>
          </div>

          {/* Region & Difficulty Info */}
          <div className="flex justify-center gap-2 mt-6">
            <Badge variant="secondary" data-testid="badge-region">
              {regionName}
            </Badge>
            <Badge variant="secondary" data-testid="badge-difficulty">
              {difficulty}
            </Badge>
          </div>
        </Card>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Link href={`/juego/${region}/${difficulty.toLowerCase()}`}>
            <Button 
              variant="default" 
              className="w-full gap-2"
              data-testid="button-play-again"
            >
              <RotateCcw className="h-4 w-4" />
              Jugar de Nuevo
            </Button>
          </Link>

          <Link href={`/dificultad/${region}`}>
            <Button 
              variant="outline" 
              className="w-full gap-2"
              data-testid="button-change-difficulty"
            >
              <Star className="h-4 w-4" />
              Cambiar Dificultad
            </Button>
          </Link>

          <Link href="/regiones">
            <Button 
              variant="outline" 
              className="w-full gap-2"
              data-testid="button-change-region"
            >
              <Map className="h-4 w-4" />
              Cambiar Región
            </Button>
          </Link>
        </div>

        {/* Return Home */}
        <div className="text-center mt-6">
          <Link href="/">
            <Button variant="ghost" className="gap-2" data-testid="button-main-menu">
              <Home className="h-4 w-4" />
              Menú Principal
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
