import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Home, ChevronLeft, Heart, Trophy, Zap } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { type Pokemon, type Difficulty, type AnswerResponse, pokemonTypes } from "@shared/schema";

export default function GameScreen() {
  const params = useParams();
  const [, navigate] = useLocation();
  const region = params.region as string;
  
  // Normalize difficulty from URL (lowercase) to proper enum value
  const difficultyParam = params.difficulty as string;
  const difficulty = (difficultyParam.charAt(0).toUpperCase() + difficultyParam.slice(1)) as Difficulty;
  
  const regionName = region.charAt(0).toUpperCase() + region.slice(1);

  // Game state
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [questionsAnswered, setQuestionsAnswered] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [lives, setLives] = useState(3);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState("");

  // Form state for different difficulties
  const [nameInput, setNameInput] = useState("");
  const [typeInputs, setTypeInputs] = useState<string[]>([]);
  const [numberInput, setNumberInput] = useState("");

  // Fetch random Pokemon
  const { data: pokemon, isLoading, refetch } = useQuery<Pokemon>({
    queryKey: ['/api/pokemon/random', region, difficulty],
    queryFn: async () => {
      const response = await fetch(`/api/pokemon/random/${region}/${difficulty}`);
      if (!response.ok) {
        throw new Error('Failed to fetch Pokemon');
      }
      return response.json();
    },
  });

  // Submit answer mutation
  const submitAnswer = useMutation({
    mutationFn: async (answerData: any) => {
      const response = await fetch('/api/pokemon/validate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(answerData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to validate answer');
      }
      
      return response.json() as Promise<AnswerResponse>;
    },
    onSuccess: (response) => {
      // Calculate all new values locally to avoid stale state
      const newQuestionsAnswered = questionsAnswered + 1;
      let newScore = score;
      let newStreak = streak;
      let newCorrectAnswers = correctAnswers;
      let newLives = lives;

      if (response.correct) {
        const points = difficulty === "Experto" ? 100 : difficulty === "Difícil" ? 50 : difficulty === "Media" ? 30 : 20;
        newScore = score + points + (streak * 10);
        newStreak = streak + 1;
        newCorrectAnswers = correctAnswers + 1;
        setFeedbackMessage("¡Correcto! 🎉");
      } else {
        newStreak = 0;
        newLives = lives - 1;
        setFeedbackMessage(
          `Incorrecto. Era: ${response.correctAnswer.name} (#${response.correctAnswer.number}) - ${response.correctAnswer.type.join(", ")}`
        );
      }

      // Update all state
      setShowFeedback(true);
      setIsCorrect(response.correct);
      setQuestionsAnswered(newQuestionsAnswered);
      setScore(newScore);
      setStreak(newStreak);
      setCorrectAnswers(newCorrectAnswers);
      setLives(newLives);

      // Next question after delay - use calculated values
      setTimeout(() => {
        setShowFeedback(false);
        resetInputs();
        
        // Check if game should continue or end
        if (newLives > 0) {
          refetch();
        } else {
          // Game over - navigate with fresh calculated values
          navigate(`/resultados?score=${newScore}&correct=${newCorrectAnswers}&total=${newQuestionsAnswered}&region=${region}&difficulty=${difficulty}`);
        }
      }, 2000);
    },
  });

  const resetInputs = () => {
    setNameInput("");
    setTypeInputs([]);
    setNumberInput("");
  };

  const handleSubmit = () => {
    if (!pokemon) return;

    // Validate inputs before submitting
    if (difficulty === "Fácil" && !nameInput.trim()) return;
    if (difficulty === "Media" && typeInputs.length === 0) return;
    if (difficulty === "Difícil" && !numberInput) return;
    if (difficulty === "Experto" && (!nameInput.trim() || typeInputs.length === 0 || !numberInput)) return;

    const answerData: any = {
      pokemonId: pokemon.id,
      difficulty,
      answer: {},
    };

    // Build answer based on difficulty
    if (difficulty === "Fácil") {
      answerData.answer.name = nameInput.trim();
    } else if (difficulty === "Media") {
      answerData.answer.type = typeInputs;
    } else if (difficulty === "Difícil") {
      answerData.answer.number = parseInt(numberInput);
    } else if (difficulty === "Experto") {
      answerData.answer.name = nameInput.trim();
      answerData.answer.type = typeInputs;
      answerData.answer.number = parseInt(numberInput);
    }

    submitAnswer.mutate(answerData);
  };

  const toggleType = (type: string) => {
    // Ensure we don't select more than 2 types
    setTypeInputs(prev => {
      if (prev.includes(type)) {
        return prev.filter(t => t !== type);
      } else if (prev.length < 2) {
        return [...prev, type];
      }
      return prev;
    });
  };

  // Note: Game over logic is now handled in the mutation success handler
  // to ensure we use fresh calculated values instead of stale state

  const progress = (questionsAnswered / 10) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/80 backdrop-blur-sm border-b border-card-border">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between mb-2">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => navigate("/regiones")}
              data-testid="button-home"
            >
              <Home className="h-5 w-5" />
            </Button>
            
            <h1 className="font-game text-xs sm:text-sm text-foreground">
              {regionName} • {difficulty}
            </h1>

            <div className="flex items-center gap-1">
              {Array.from({ length: 3 }).map((_, i) => (
                <Heart
                  key={i}
                  className={`h-5 w-5 ${
                    i < lives 
                      ? "fill-pokemon-red text-pokemon-red" 
                      : "text-muted-foreground"
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Stats */}
          <div className="flex items-center justify-between gap-4 text-xs sm:text-sm">
            <Badge variant="secondary" className="gap-1" data-testid="badge-score">
              <Trophy className="h-3 w-3" />
              {score}
            </Badge>
            <Badge variant="secondary" className="gap-1" data-testid="badge-streak">
              <Zap className="h-3 w-3" />
              {streak}
            </Badge>
            <span className="text-muted-foreground">
              {correctAnswers}/{questionsAnswered}
            </span>
          </div>

          <Progress value={progress} className="mt-2 h-1.5" />
        </div>
      </header>

      {/* Main Game Area */}
      <main className="max-w-2xl mx-auto px-4 py-8 animate-slide-up">
        {isLoading || !pokemon ? (
          <Card className="p-12">
            <div className="flex flex-col items-center gap-4">
              <div className="w-16 h-16 border-4 border-pokemon-blue border-t-transparent rounded-full animate-spin" />
              <p className="text-muted-foreground">Cargando Pokémon...</p>
            </div>
          </Card>
        ) : (
          <Card className="p-6 sm:p-8 relative overflow-hidden">
            {/* Feedback Overlay */}
            {showFeedback && (
              <div
                className={`absolute inset-0 z-50 flex items-center justify-center ${
                  isCorrect ? "bg-easy-green/90" : "bg-expert-red/90"
                } ${isCorrect ? "animate-pulse-scale" : "animate-shake"}`}
              >
                <div className="text-white text-center p-6">
                  <p className="font-game text-xl sm:text-2xl mb-2">
                    {isCorrect ? "¡Correcto!" : "Incorrecto"}
                  </p>
                  <p className="text-sm sm:text-base">{feedbackMessage}</p>
                </div>
              </div>
            )}

            {/* Pokemon Display */}
            <div className="text-center mb-6">
              <div className="inline-block bg-muted/30 rounded-xl p-8 mb-4">
                <img
                  src={pokemon.spriteUrl}
                  alt={difficulty === "Fácil" || difficulty === "Experto" ? "???" : pokemon.name}
                  className="w-48 h-48 sm:w-64 sm:h-64 object-contain mx-auto pixelated"
                  data-testid="img-pokemon-sprite"
                />
              </div>

              {/* Show name for Media and Difícil */}
              {(difficulty === "Media" || difficulty === "Difícil") && (
                <h2 className="font-game text-2xl sm:text-3xl text-foreground mb-2" data-testid="text-pokemon-name">
                  {pokemon.name}
                </h2>
              )}
            </div>

            {/* Question & Input based on difficulty */}
            <div className="space-y-4">
              {/* Fácil: Guess name */}
              {difficulty === "Fácil" && (
                <>
                  <h3 className="text-center font-semibold text-lg">
                    ¿Cuál es el nombre de este Pokémon?
                  </h3>
                  <Input
                    placeholder="Escribe el nombre..."
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                    className="text-center text-lg"
                    data-testid="input-pokemon-name"
                  />
                </>
              )}

              {/* Media: Guess type */}
              {difficulty === "Media" && (
                <>
                  <h3 className="text-center font-semibold text-lg">
                    ¿Cuál es el tipo de {pokemon.name}?
                  </h3>
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                    {pokemonTypes.map((type) => (
                      <Button
                        key={type}
                        variant={typeInputs.includes(type) ? "default" : "outline"}
                        size="sm"
                        onClick={() => toggleType(type)}
                        className="text-xs"
                        data-testid={`button-type-${type.toLowerCase()}`}
                      >
                        {type}
                      </Button>
                    ))}
                  </div>
                  <p className="text-xs text-center text-muted-foreground">
                    Selecciona uno o dos tipos
                  </p>
                </>
              )}

              {/* Difícil: Guess number */}
              {difficulty === "Difícil" && (
                <>
                  <h3 className="text-center font-semibold text-lg">
                    ¿Cuál es el número de Pokédex de {pokemon.name}?
                  </h3>
                  <Input
                    type="number"
                    placeholder="Número de Pokédex..."
                    value={numberInput}
                    onChange={(e) => setNumberInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                    className="text-center text-lg"
                    data-testid="input-pokemon-number"
                  />
                </>
              )}

              {/* Experto: All three */}
              {difficulty === "Experto" && (
                <>
                  <h3 className="text-center font-semibold text-lg text-expert-red">
                    ¡Modo Experto! Adivina TODO
                  </h3>
                  
                  <div className="space-y-3">
                    <div>
                      <label className="text-sm font-semibold mb-1 block">Nombre:</label>
                      <Input
                        placeholder="Nombre del Pokémon"
                        value={nameInput}
                        onChange={(e) => setNameInput(e.target.value)}
                        className="text-center"
                        data-testid="input-pokemon-name"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-semibold mb-1 block">Tipo(s):</label>
                      <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                        {pokemonTypes.map((type) => (
                          <Button
                            key={type}
                            variant={typeInputs.includes(type) ? "default" : "outline"}
                            size="sm"
                            onClick={() => toggleType(type)}
                            className="text-xs"
                            data-testid={`button-type-${type.toLowerCase()}`}
                          >
                            {type}
                          </Button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="text-sm font-semibold mb-1 block">Número de Pokédex:</label>
                      <Input
                        type="number"
                        placeholder="Número"
                        value={numberInput}
                        onChange={(e) => setNumberInput(e.target.value)}
                        className="text-center"
                        data-testid="input-pokemon-number"
                      />
                    </div>
                  </div>
                </>
              )}

              {/* Submit Button */}
              <Button
                onClick={handleSubmit}
                disabled={submitAnswer.isPending || showFeedback}
                className="w-full text-lg py-6 font-bold uppercase"
                size="lg"
                data-testid="button-submit-answer"
              >
                {submitAnswer.isPending ? "Verificando..." : "Confirmar"}
              </Button>
            </div>
          </Card>
        )}
      </main>

      <style>{`
        .pixelated {
          image-rendering: pixelated;
          image-rendering: -moz-crisp-edges;
          image-rendering: crisp-edges;
        }
      `}</style>
    </div>
  );
}
