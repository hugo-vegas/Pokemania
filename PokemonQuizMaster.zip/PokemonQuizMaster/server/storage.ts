import { type Pokemon, type Region } from "@shared/schema";
import pokemonData from "./data/pokemon-data.json";

export interface IStorage {
  getRandomPokemon(region: Region): Promise<Pokemon | undefined>;
  getPokemonById(id: number): Promise<Pokemon | undefined>;
  getAllPokemon(): Promise<Pokemon[]>;
  getPokemonByRegion(region: Region): Promise<Pokemon[]>;
}

export class MemStorage implements IStorage {
  private pokemonByRegion: Map<Region, Pokemon[]>;
  private allPokemon: Pokemon[];

  constructor() {
    this.pokemonByRegion = new Map();
    this.allPokemon = [];

    // Load Pokemon data from JSON
    Object.entries(pokemonData).forEach(([region, pokemon]) => {
      const regionKey = region as Region;
      this.pokemonByRegion.set(regionKey, pokemon as Pokemon[]);
      this.allPokemon.push(...(pokemon as Pokemon[]));
    });
  }

  async getRandomPokemon(region: Region): Promise<Pokemon | undefined> {
    let pokemonList: Pokemon[] = [];
    
    if (region === "General") {
      pokemonList = this.allPokemon;
    } else {
      pokemonList = this.pokemonByRegion.get(region) || [];
    }

    if (pokemonList.length === 0) return undefined;

    const randomIndex = Math.floor(Math.random() * pokemonList.length);
    return pokemonList[randomIndex];
  }

  async getPokemonById(id: number): Promise<Pokemon | undefined> {
    return this.allPokemon.find(p => p.id === id);
  }

  async getAllPokemon(): Promise<Pokemon[]> {
    return this.allPokemon;
  }

  async getPokemonByRegion(region: Region): Promise<Pokemon[]> {
    if (region === "General") {
      return this.allPokemon;
    }
    return this.pokemonByRegion.get(region) || [];
  }
}

export const storage = new MemStorage();
