import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { type Region, type Difficulty, answerSchema, regions } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // GET /api/regions - Get all available regions
  app.get("/api/regions", async (_req, res) => {
    try {
      res.json(regions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch regions" });
    }
  });

  // GET /api/pokemon/random/:region/:difficulty - Get random Pokemon
  app.get("/api/pokemon/random/:region/:difficulty", async (req, res) => {
    try {
      const { region, difficulty } = req.params;
      
      // Capitalize region name to match Region type
      const regionName = region.charAt(0).toUpperCase() + region.slice(1) as Region;
      
      const pokemon = await storage.getRandomPokemon(regionName);
      
      if (!pokemon) {
        return res.status(404).json({ error: "No Pokemon found for this region" });
      }

      res.json(pokemon);
    } catch (error) {
      console.error("Error fetching random Pokemon:", error);
      res.status(500).json({ error: "Failed to fetch Pokemon" });
    }
  });

  // POST /api/pokemon/validate - Validate user's answer
  app.post("/api/pokemon/validate", async (req, res) => {
    try {
      const validatedData = answerSchema.parse(req.body);
      const { pokemonId, difficulty, answer } = validatedData;

      const pokemon = await storage.getPokemonById(pokemonId);

      if (!pokemon) {
        return res.status(404).json({ error: "Pokemon not found" });
      }

      let correct = false;

      // Validate based on difficulty
      if (difficulty === "Fácil") {
        // Check name (case insensitive)
        const userAnswer = answer.name?.toLowerCase().trim() || "";
        const correctAnswer = pokemon.name.toLowerCase().trim();
        correct = userAnswer === correctAnswer;
      } else if (difficulty === "Media") {
        // Check types (order doesn't matter)
        const userTypes = answer.type || [];
        const correctTypes = pokemon.types;
        
        // Both arrays should have same length and contain same elements
        correct = 
          userTypes.length === correctTypes.length &&
          userTypes.every(type => correctTypes.includes(type)) &&
          correctTypes.every(type => userTypes.includes(type));
      } else if (difficulty === "Difícil") {
        // Check Pokedex number
        const userNumber = answer.number || 0;
        correct = userNumber === pokemon.number;
      } else if (difficulty === "Experto") {
        // Check all three: name, types, and number
        const nameCorrect = 
          (answer.name?.toLowerCase().trim() || "") === pokemon.name.toLowerCase().trim();
        
        const userTypes = answer.type || [];
        const correctTypes = pokemon.types;
        const typesCorrect = 
          userTypes.length === correctTypes.length &&
          userTypes.every(type => correctTypes.includes(type)) &&
          correctTypes.every(type => userTypes.includes(type));
        
        const numberCorrect = (answer.number || 0) === pokemon.number;
        
        correct = nameCorrect && typesCorrect && numberCorrect;
      }

      res.json({
        correct,
        correctAnswer: {
          name: pokemon.name,
          type: pokemon.types,
          number: pokemon.number,
        },
        message: correct 
          ? "¡Correcto! 🎉" 
          : `Incorrecto. La respuesta era: ${pokemon.name} (#${pokemon.number}) - ${pokemon.types.join(", ")}`,
      });
    } catch (error) {
      console.error("Error validating answer:", error);
      res.status(400).json({ error: "Invalid request" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
